const employmentLocation = [
    {
        area: "Areas of strategic importance",
        sector: "Advanced Manufacturing",
        north_east_lep: 1.1,
        northumberland: 1.0,
        newcastle_upon_tyne: 0.5,
        north_tyneside: 1.0,
        gateshead: 1.1,
        south_tyneside: 1.0,
        sunderland: 1.9,
        county_durham: 1.4
    },

    {
    
        area: "Areas of strategic importance",
        sector: "Digital Tech",
        north_east_lep: 0.8,
        northumberland: 0.3,
        newcastle_upon_tyne: 1.3,
        north_tyneside: 1.7,
        gateshead: 0.9,
        south_tyneside: 0.4,
        sunderland: 0.5,
        county_durham: 0.3
    },

    {
        area: "Areas of strategic importance",
        sector: "Energy",
        north_east_lep: 1.0,
        northumberland: 1.0,
        newcastle_upon_tyne: 0.7,
        north_tyneside: 1.1,
        gateshead: 1.0,
        south_tyneside: 1.3,
        sunderland: 1.5,
        county_durham: 0.9
    },

    {
        area: "Areas of strategic importance",
        sector: "Health and Life Sciences",
        north_east_lep: 0.7,
        northumberland: 1.5,
        newcastle_upon_tyne: 0.3,
        north_tyneside: 0.8,
        gateshead: 0.2,
        south_tyneside: 0.5,
        sunderland: 0.4,
        county_durham: 1.3
    },

    {
        area: "Areas of strategic importance",
        sector: "Knowledge intensive business services",
        north_east_lep: 0.7,
        northumberland: 0.5,
        newcastle_upon_tyne: 1.1,
        north_tyneside: 1.0,
        gateshead: 0.6,
        south_tyneside: 0.5,
        sunderland: 0.7,
        county_durham: 0.4
    },

    {
        area: "Enabling sectors",
        sector: "Construction",
        north_east_lep: 0.8,
        northumberland: 0.9,
        newcastle_upon_tyne: 0.6,
        north_tyneside: 0.7,
        gateshead: 0.9,
        south_tyneside: 1.2,
        sunderland: 0.8,
        county_durham: 1.0
    },

    {
        area: "Enabling sectors",
        sector: "Education",
        north_east_lep: 1.1,
        northumberland: 0.8,
        newcastle_upon_tyne: 1.3,
        north_tyneside: 0.7,
        gateshead: 0.9,
        south_tyneside: 1.1,
        sunderland: 0.9,
        county_durham: 1.3
    },
    
    {
        area: "Enabling sectors",
        sector: "Logistics",
        north_east_lep: 0.6,
        northumberland: 0.5,
        newcastle_upon_tyne: 0.2,
        north_tyneside: 0.3,
        gateshead: 0.7,
        south_tyneside: 0.9,
        sunderland: 1.0,
        county_durham: 0.8
    }
];

new DataTable('#employmentLocation', {
    data: employmentLocation,
    pageLength: 25,

    columns: [
        { data: 'area', title: 'Area' },
        { data: 'sector', title: 'Sector' },
        { data: 'north_east_lep', title: 'North East LEP' },
        { data: 'northumberland', title: 'Northumberland' },
        { data: 'newcastle_upon_tyne', title: 'Newcastle Upon Tyne' },
        { data: 'north_tyneside', title: 'North Tyneside' },
        { data: 'gateshead', title: 'Gateshead' },
        { data: 'south_tyneside', title: 'South Tyneside' },
        { data: 'sunderland', title: 'Sunderland' },
        { data: 'county_durham', title: 'County Durham' }
    ],

    order: [[1, 'asc']]
});
