const HighestFootballPlayerSalaries = [
    {
        player_team: "Manchester City",
        player_name: "Erling Braut Haaland",
        player_market_value: 220000000,
        player_age: 26,
        player_position: "Striker",
        season_goals: 121,
        season_assists: 24,
        player_appearances: 142,
    },

    {
        player_team: "Manchester City",
        player_name: "Elliot Anderson",
        player_market_value: 120000000,
        player_age: 24,
        player_position: "Midfielder",
        season_goals: 6,
        season_assists: 14,
        player_appearances: 129,
    },

    {
        player_team: "Chelsea FC",
        player_name: "Morgan Rogers",
        player_market_value: 120000000,
        player_age: 24,
        player_position: "Midfielder",
        season_goals: 26,
        season_assists: 18,
        player_appearances: 95,
    },

    {
        player_team: "Manchester City",
        player_name: "Enzo Fernandez",
        player_market_value: 120000000,
        player_age: 25,
        player_position: "Midfielder",
        season_goals: 20,
        season_assists: 15,
        player_appearances: 127,
    },

    {
        player_team: "Arsenal FC",
        player_name: "Declan Rice",
        player_market_value: 120000000,
        player_age: 27,
        player_position: "Midfielder",
        season_goals: 25,
        season_assists: 35,
        player_appearances: 323,
    }
];

new DataTable('#HighestFootballPlayerSalaries', {
    data: HighestFootballPlayerSalaries,
    pageLength: 5,

    columns: [
        {data: 'player_team', title: 'Team'},
        {data: 'player_name', title: 'Name'},
        {data: 'player_market_value', title: 'Market Value', render: DataTable.render.number(',', '.', 0, '€', 'M')},
        {data: 'player_age', title: 'Age' },
        {data: 'player_position', title: 'Position'},
        {data: 'season_goals', title: 'Season Goals'},
        {data: 'season_assists', title: 'Season Assists'},
        {data: 'player_appearances', title: 'Player Appearances'},
    ],

    order: [[1, 'asc']]
});
