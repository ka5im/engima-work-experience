<template>

  <div class="game-product-card">


    <h2>{{ name }}</h2>

      <img :src="image" :alt="name" height="200px" width="200px"/>

    <p v-if="status" class="show-status">{{ status }}</p>
  
    <h3 v-if="price" class="show-price">£{{Number(price ?? 0).toFixed(2) }}</h3>

    <button @click="viewProduct" class="view-product-btn">View Product</button><br>

    <button @click="purchase" class="purchase-product-btn">Purchase</button>
  </div>
  
</template>

<script>
export default {
  name: "ProductCard",

  props: {
    id: { type: [String, Number], required: true },
    slug_url: String, required: true,
    name: String,
    price: Number,
    image: String,
    status: String,
  },

  methods: {
    viewProduct() {
      this.$router.push(`/product_details/${this.id}/${this.slug_url}`);
    }
  }
};
</script>
