<template>
  <div class="welcome-msg">
    <h1>Welcome to the Homepage</h1>
  </div>
</template>

<script>
export default {
  name: "Home",
};
</script>
