<template>
  <div class="welcome-msg">
    <h1>Welcome to the About Section</h1>
  </div>
</template>

  <script>
    export default {
      name: "About",
    };
  </script>
