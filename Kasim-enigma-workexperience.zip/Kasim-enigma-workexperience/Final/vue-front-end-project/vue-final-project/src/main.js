import { createApp } from 'vue';
import App from './App.vue';
import router from './router/index.js';
import './style/product_card_style.css';
createApp(App).use(router).mount('#app');