<template>
  <div class="information">
    <h1>Welcome to the About Section</h1>

    <p>This Vue Application is designed to show a Products page of items</p>
  </div>
</template>

  <script>
    export default {
      name: "About",
    };
  </script>
