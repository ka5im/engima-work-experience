<template>
  <div v-if="product" className="game-product-card-details">

    <h1>You are Purchasing {{ product.name }} for the platform {{ product.platform }}</h1>

    <h2>{{ product.name }}</h2>

    <img :src="product.image" alt="product.name" />

    <h2>£{{ Number(product.price ?? 0).toFixed(2) }}</h2>
    <h2>{{ product.platform }}</h2>
    <h2>{{ product.status }}</h2>
    <h2>{{ product.game_developer_studio }}</h2>
    <h2>{{ product.edition }}</h2>
    <h2>{{ product.age_rating }}</h2>
    <h2>{{ product.game_rating }}</h2>

    <h2>{{ product.game_description }}</h2>
  </div>

    <div class="return-to-prev-page-btn">
    <router-link to="/product"><button>Back</button></router-link>
  </div>
  
</template>

<script>

import products from '../data/products.json';
export default {
  name: "product_details",

  props: {
    id: { type: [String, Number], required: true },
    slug_url: String, required: true,
    name: String,
    price: Number,
    image: String,
    platform: String,
    status: String,
    game_developer_studio: String,
    game_version: String,
    edition: String,
    age_rating: String,
    game_rating: String,
    game_description: String
  },

  computed: {
    product() {
      const productId = this.id ?? this.$route.params.id;
      return products.find(
        product => product.id === Number(productId)
      );
    }
  }
};
</script>
