<template>

  <div class="shopping-cart-msg">
    <h1>Your Shopping Cart</h1>

  <p class="display-basket-item-amount">Current Items in Shopping Cart:</p>
  </div>

</template>

<script>
export default {
  name: "shopping_cart",
};
</script>
