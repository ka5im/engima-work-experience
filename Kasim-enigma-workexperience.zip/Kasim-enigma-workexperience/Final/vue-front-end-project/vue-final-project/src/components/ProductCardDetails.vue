<template>
  <div v-if="product" className="game-product-card-details">

    <h1 class="product-detail-msg-overhead">Product Details:</h1><br>

    <h2 class="viewing-game-name">Viewing: {{ product.name }}</h2>

    <div class="product-detail-style">
      <img :src="product.image" alt="product.name" height="200px" width="200px"/>

    <h2 class="show-price">£{{ Number(product.price ?? 0).toFixed(2) }}</h2>
    <h2 class="show-platform">{{ product.platform }}</h2>
    <h2 class="show-status">{{ product.status }}</h2>
    <h2 class="show-game-dev-studio">{{ product.game_developer_studio }}</h2>
    <h2 class="show-edition">{{ product.edition }}</h2>
    <h2 class="show-age-rating">{{ product.age_rating }}</h2>
    <h2 class="show-game-rating">{{ product.game_rating }}</h2>
      <hr>
    <h2>Product Description</h2>
    <h2 class="show-game-desc">{{ product.game_description }}</h2>
    <br>
  </div>
  </div>

  <div class="product-not-found-error" v-else>
    <h1>Error - Product Not Found</h1>
    <router-link to="/product">Go Back</router-link>
  </div>

  <div class="return-to-prev-page-btn">
    <router-link to="/product"><button>Back</button></router-link>
  </div>

</template>


<script>

import products from '../data/products.json';
export default {
  name: "product_details",

  props: {
    id: { type: [String, Number], required: true },
    slug_url: String, required: true,
    name: String,
    price: Number,
    image: String,
    platform: String,
    status: String,
    game_developer_studio: String,
    game_version: String,
    edition: String,
    age_rating: String,
    game_rating: String,
    game_description: String
  },

  computed: {
    product() {
      const productId = this.id ?? this.$route.params.id;
      return products.find(
        product => product.id === Number(productId)
      );
    }
  }
};
</script>
