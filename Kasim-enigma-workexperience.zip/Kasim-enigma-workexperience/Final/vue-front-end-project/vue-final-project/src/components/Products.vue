<template>
    <div class="products-page">

        <h1 class="overhead-product-tag">Products</h1><hr>

        <h2 class="product-type">Games</h2>

        <div class="product-lists">

            <ProductCard
                v-for="product in products"
                :key="product.id"
                :id="product.id"
                :slug_url="product.slug_url"
                :name="product.name"
                :image="product.image"
                :price="product.price"
                :status="product.status"/>
        </div>

        <p v-if="products.length === 0">No Products Available.</p>
 </div>

</template>

<script>
import products from '../data/products.json';
import ProductCard from '../components/ProductCard.vue';

export default {
    name: "Products",

    components: {
        ProductCard
    },

    data() {
        return {
            products: products
        };
    }
};
</script>
