<template>

  <div class="welcome-msg">
    <h1>Welcome to the Homepage</h1>

    <p>This website showcases the different Products available in my application.</p>
  </div>
  
</template>

<script>
export default {
  name: "Home",
};
</script>
