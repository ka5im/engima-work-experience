<template>

  <div class="header-navigation">
    <nav>
      <ul>
      <router-link to="/">Home</router-link>
      <router-link to="/product">Products</router-link>
      <router-link to="shopping_cart">Basket</router-link>
      <router-link to="/about">About</router-link>
      </ul>
    </nav>
  </div>
  
  <router-view></router-view>
</template>