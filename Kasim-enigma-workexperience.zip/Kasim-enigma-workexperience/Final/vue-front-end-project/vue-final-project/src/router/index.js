import {createRouter, createWebHistory} from 'vue-router';

import Home from '../components/Home.vue';
import Products from '../view/Products.vue';
import ProductCard from '../components/ProductCard.vue';
import ProductCardDetails from '../components/ProductCardDetails.vue';
import ShoppingCart from '../components/ShoppingCart.vue';
import About from '../components/About.vue';

const routes = [
    { path: '/', component: Home, props: true },
    {path: '/product', component: Products, props: true},
    { path: '/products/:id/:slug_url', component: ProductCard, props: true },
    { path: '/product_details/:id/:slug_url', component: ProductCardDetails, props: true },
    {path: '/shopping_cart', component: ShoppingCart, props: true},
    {path:'/about', component: About, props: true}
];

const router = createRouter({
    history: createWebHistory(), routes
});

export default router;