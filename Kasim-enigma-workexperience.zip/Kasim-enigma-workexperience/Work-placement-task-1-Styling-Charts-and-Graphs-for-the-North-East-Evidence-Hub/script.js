const myCanvas = document.getElementById("myCanvas");

const PremierLeagueClubs = [
  {
    club_name: "Manchester City",
    clubValue: "150000",
    avg_age: 24.7,
    best_player: "Erling Haaland"
  },
  {
    club_name: "Arsenal FC",
    clubValue: "138000",
    avg_age: 26.5,
    best_player: "Bukayo Saka"
  },
  {
    club_name: "Chelsea FC",
    clubValue: "115000",
    avg_age: 24.6,
    best_player: "Moises Caicedo"
  },
  {
    club_name: "Liverpool FC",
    clubValue: "109000",
    avg_age: 25.1,
    best_player: "Szoboszlai"
  },
  {
    club_name: "Manchester United",
    clubValue: "92880",
    avg_age: 26.0,
    best_player: "Cunha"
  },
  {
    club_name: "Tottenham Hotspur",
    clubValue: "83600",
    avg_age: 25.4,
    best_player: "Omar Marmoush"
  },
  {
    club_name: "Newcastle United",
    clubValue: "71210",
    avg_age: 24.7,
    best_player: "Harvey Barnes"
  },
  {
    club_name: "Brighton FC",
    clubValue: "70000",
    avg_age: 25.3,
    best_player: "Pascal Gross"
  },
  {
    club_name: "Brentford FC",
    clubValue: "63380",
    avg_age: 26.4,
    best_player: "Igor Thiago"
  },
  {
    club_name: "Aston Villa",
    clubValue: "63370",
    avg_age: 26.4,
    best_player: "John Mginn"
  },
  {
    club_name: "AFC Bournemouth",
    clubValue: "62440",
    avg_age: 25.7,
    best_player: "Marcus Tavanier"
  },
  {
    club_name: "Crystal Palace",
    clubValue: "60320",
    avg_age: 25.9,
    best_player: "Jean-Phillipe-Mateta"
  },
  {
    club_name: "Nottingham Forest",
    clubValue: "55400",
    avg_age: 26.6,
    best_player: "Morgan Gibbs White"
  },
  {
    club_name: "Sunderland AFC",
    clubValue: "45858",
    avg_age: 25.9,
    best_player: "Granit Xhaka"
  },
  {
    club_name: "Leeds United",
    clubValue: "45355",
    avg_age: 26.7,
    best_player: "Dolminic Calvin-Lewin"
  },
  {
    club_name: "Everton FC",
    clubValue: "43680",
    avg_age: 25.7,
    best_player: "Beto"
  },
  {
    club_name: "Fulham FC",
    clubValue: "41860",
    avg_age: 26.0,
    best_player: "Harry Wilson"
  },
  {
    club_name: "Ipswich Town",
    clubValue: "38075",
    avg_age: 25.9,
    best_player: "Liam Delap"
  },
  {
    club_name: "Coventry City",
    clubValue: "32270",
    avg_age: 26.1,
    best_player: "Carl Rushworth"
  },
  {
    club_name: "Hull City",
    clubValue: "29530",
    avg_age: 26.0,
    best_player: "Oliver Mcburnie"
  }
];

const myChart = new Chart(myCanvas, {
  type: "bar",
  data: {
    labels: PremierLeagueClubs.map((c) => c.club_name),

    datasets: [
      {
        type: "bar",
        label: "Team Average Squad Age",
        data: PremierLeagueClubs.map((a) => a.avg_age),
        backgroundColor: "#00FFFF",
        borderColor: "#00BFFF",
        borderWidth: 3,
        yAxisID: "yAge"
      },

      {
        type: "bar",
        label: "Club Value (€ Billions)",
        data: PremierLeagueClubs.map((v) => v.clubValue),
        backgroundColor: "Red",
        borderColor: "Crimson",
        borderWidth: 3,
        yAxisID: "yValue"
      },

      {
        type: "bar",
        label: "Best player (nominated 25/26 season)",
        data: PremierLeagueClubs.map((b) => b.best_player),
        backgroundColor: "Purple",
        borderColor: "Violet",
        BorderWidth: 3
      }
    ]
  },

  options: {
    animation: {
      duration: 1000,
      easing: "linear",
      loop: false
    },

    scales: {
      x: {
        title: {
          display: true,
          text: "Clubs"
        }
      },
      y: {
        title: {
          display: true,
          text: "Average Age",
        }
      }
    }
  }
});
