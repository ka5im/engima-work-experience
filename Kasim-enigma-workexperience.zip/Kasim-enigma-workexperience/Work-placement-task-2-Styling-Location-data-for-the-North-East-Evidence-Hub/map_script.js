const map = L.map('map').setView([51.50853, -0.12574], 3); // default location set to London

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
	maxZoom: 19,
	attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

// Show which Gaming Console Generation was the most popular across the world (2021 Statistics)

//coordinate locations found here: https://gps-coordinates.org/countries.php (apart from North America)
// where i found the most popular consoles: https://geektyrant.com/news/discover-each-countrys-most-popular-game-consoles and
// https://en.wikipedia.org/wiki/List_of_best-selling_game_consoles_by_region

// latitude, longitude, zoom level

var USA = L.marker([39.381266, -97.922211]).addTo(map);
var GreatBritain = L.marker([54.237933, -2.36967]).addTo(map);
var NorthAmerica = L.marker([54.5260, -105.2551]).addTo(map);
var Canada = L.marker([55.585901, -105.750596]).addTo(map);
var Germany = L.marker([51.133481, -10.018343]).addTo(map);
var France = L.marker([47.824905, -2.618787]).addTo(map);
var Italy = L.marker([42.504154, 12.646361]).addTo(map);
var Malaysia = L.marker([3.140853, 101.693207]).addTo(map);
var Spain = L.marker([41.294856, -4.055685]).addTo(map);
var Japan = L.marker([36.386493, 138.59223]).addTo(map);
var Australia = L.marker([-25.734968, 134.489563]).addTo(map);
var Egypt = L.marker([26.494184, 29.871903]).addTo(map);
var Argentina = L.marker([-35.376184, -63.998128]).addTo(map);
var Namibia = L.marker([-22.95764, 18.49041]).addTo(map);


USA.bindPopup("<p>United States: Sony PlayStation 5 </p>").openPopup();
GreatBritain.bindPopup("<p>Great Britain: Xbox series X</p>").openPopup();
NorthAmerica.bindPopup("<p>North America: Sony Playstation 5</p>").openPopup();
Canada.bindPopup("<p>Canada: Xbox Series X</p>").openPopup();
Germany.bindPopup("<p>Germany: Nintendo Switch </p>").openPopup();
France.bindPopup("<p>France: Nintendo Switch</p>").openPopup();
Italy.bindPopup("<p>Italy: Sony Playstation 5</p>").openPopup();
Malaysia.bindPopup("<p>Malaysia: Nintendo Switch</p>").openPopup();
Spain.bindPopup("<p>Spain: Sony PlayStation 5</p>").openPopup();
Japan.bindPopup("<p>Japan: Sony Playstation 5</p>").openPopup();
Australia.bindPopup("<p>Australia: Sony Playstation 5</p>").openPopup();
Egypt.bindPopup("<p>Egypt: Sony PlayStation 5 </p>").openPopup();
Argentina.bindPopup("<p>Argentina: Sony Playstation 4</p>").openPopup();
Namibia.bindPopup("<p>Namibia: Xbox 360</p>").openPopup();
