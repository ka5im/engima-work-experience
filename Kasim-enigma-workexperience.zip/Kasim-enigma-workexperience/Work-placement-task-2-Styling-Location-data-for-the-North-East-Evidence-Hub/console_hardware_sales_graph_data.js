const myCanvas = document.getElementById("myCanvas");

const ConsoleDevices = [
    
    {
    console_name: "Sony PlayStation 5",
    console_release_date: 2020,
    console_unit_sales: 99015253,
    total_game_exclusives: 52,
    launch_price: 499,
    price: 550,
    fps: 120
},

    {
    console_name: "Nintendo Switch 2",
    console_release_date: 2025,
    console_unit_sales: 28410227,
    total_game_exclusives: 15,
    launch_price: 419,
    price: 449,
    fps: 60
},

    {
    console_name: "Xbox Series X",
    console_release_date: 2020,
    console_unit_sales: 35752588,
    total_game_exclusives: 6,
    launch_price: 499,
    price: 799,
    fps: 120
},

    {
    console_name: "Xbox Series S",
    console_release_date: 2020,
    console_unit_sales: 35752588,
    total_game_exclusives: 6,
    launch_price: 299,
    price: 450,
    fps: 120
},

    {
    console_name: "Nintendo Switch",
    console_release_date: 2017,
    console_unit_sales: 157348198,
    total_game_exclusives: 6,
    launch_price: 299,
    price: 259,
    fps: 30
},

    {
    console_name: "Steam Deck",
    console_release_date: 2022,
    console_unit_sales: 4949000,
    total_game_exclusives: 0,
    launch_price: 399,
    price: 949,
    fps: 90
}
]

const myChart2 = new Chart(myCanvas, {
    type: "bar",
    data: {
        labels: ConsoleDevices.map((n) => n.console_name),

        datasets: [
            {
                type: "bar",
                label: "Units sold",
                data: ConsoleDevices.map((n) => n. console_unit_sales),
                backgroundColor: "#00FFFF",
                borderColor: "#18c5c5ff",
                borderWidth: 3,
                yAxisID:"yConsoleName"
            },

             {
                type: "bar",
                label: "No. of Game Exclusives",
                data: ConsoleDevices.map((e) => e. total_game_exclusives),
                backgroundColor: "#ae00ffff",
                borderColor: "#8317b6ff",
                borderWidth: 3,
                yAxisID:"yConsoleReleaseDate"
            },

            {
                type: "bar",
                label: "Console Cost",
                data: ConsoleDevices.map((p) => p.price),
                backgroundColor: "#1deb38ff",
                borderColor: "#1bb930ff",
                borderWidth: 3,
                yAxisID: "yConsoleCost"
            },

            {
                type: "bar",
                label: "Launch Price",
                data: ConsoleDevices.map((lp) => lp.launch_price),
                backgroundColor: "#fbff1aff",
                borderColor: "#babd13ff",
                borderWidth: 3,
                yAxisID: "yLaunchPrice"
            },

             {
                type: "bar",
                label: "Capable FPS",
                data: ConsoleDevices.map((fps) => fps.fps),
                backgroundColor: "#ff9e1fff",
                borderColor:"#da8415ff",
                borderWidth: 3,
                yAxisID: "yFPS"
            },
        ]
    },

    options: {
    animation: {
      duration: 1000,
      easing: "linear",
      loop: false
    },

    scales: {
      x: {
        title: {
          display: true,
          text: "Console Name"
        }
      },
      y: {
        title: {
          display: true,
          text: "Units Sold",

        }
      }
    }
  }
})
