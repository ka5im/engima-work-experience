const myCanvas = document.getElementById("myCanvas");

const BestSellingDevices = [
    
    {
    console_name: "Sony PlayStation 2",
    console_unit_sales: 160000000
},

    {
    console_name: "Nintendo Switch",
    console_unit_sales: 157000000,
},

    {
    console_name: "Nintendo DS",
    console_unit_sales: 154000000,
},

    {
    console_name: "Game Boy / Game Boy Color",
    console_unit_sales: 119000000,
},

    {
    console_name: "Sony Playstation 4",
    console_unit_sales: 117000000,
},

    {
    console_name: "Sony PlayStation",
    console_unit_sales: 102000000,
},

    {
    console_name: "Nintendo Wii",
    console_unit_sales: 102000000,
},

    {
    console_name: "Sony PlayStation 5",
    console_unit_sales: 990000,
},

    {
    console_name: "Sony PlayStation 3",
    console_unit_sales: 87040000,
},

    {
    console_name: "Xbox 360",
    console_unit_sales: 8400000,
}]

const myChart2 = new Chart(myCanvas, {
    type: "bar",
    data: {
        labels: BestSellingDevices.map((n) => n.console_name),

        datasets: [
            {
                type: "bar",
                label: "Units sold",
                data: BestSellingDevices.map((s) => s. console_unit_sales),
                backgroundColor: "#00FFFF",
                borderColor: "#18c5c5ff",
                borderWidth: 3,
                yAxisID:"yConsoleUnitSales"
            },
        ]
    },

    options: {
    animation: {
      duration: 1000,
      easing: "linear",
      loop: false
    },

    scales: {
      x: {
        title: {
          display: true,
          text: "Console Name"
        }
      },
      y: {
        title: {
          display: true,
          text: "Units Sold",

        }
      }
    }
  }
})
